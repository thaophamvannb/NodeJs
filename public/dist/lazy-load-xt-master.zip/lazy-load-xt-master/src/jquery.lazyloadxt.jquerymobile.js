/*jslint browser:true, plusplus:true, vars:true */
/*jshint browser:true, jquery:true */

(function ($) {
    'use strict';

    $.lazyLoadXT.updateEvent += ' collapsibleexpand filterablefilter pagechange panelopen popupafteropen tabsactivate';
})(window.jQuery || window.Zepto || window.$);
